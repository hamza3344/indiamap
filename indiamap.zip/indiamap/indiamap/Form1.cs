﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LiveCharts.WinForms;

namespace indiamap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GeoMap geomap = new GeoMap();
            Random random = new Random();
            Dictionary<string, double> values = new Dictionary<string, double>();
            values["2973"] = random.Next(0, 100);
            values["2974"] = random.Next(0, 100);
            values["2975"] = random.Next(0, 100);
            geomap.HeatMap = values;
            geomap.Hoverable = true;


            //link for the xml file is in description
            geomap.Source = $"{Application.StartupPath}\\india.xml";
            this.Controls.Add(geomap);
            geomap.Dock = DockStyle.Fill;
        }
    }
}
